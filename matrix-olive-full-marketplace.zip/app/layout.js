import "./globals.css";

export const metadata = {
 title:"Matrix Olive Marketplace",
 description:"Futuristic B2B Marketplace"
}

export default function RootLayout({children}){
 return(
  <html>
   <body>{children}</body>
  </html>
 )
}