# Matrix Olive Full Marketplace

Features:
- Product marketplace
- Purchase buttons
- Supplier structure
- Alibaba inspired layout
- Responsive UI

Future Upgrade Suggestions:
- MongoDB/MySQL
- User Authentication
- Admin Dashboard
- Real Payment Gateway
- Order Tracking
- Supplier Verification
- Live Chat
- Multi Vendor System
- AI Product Search

Run:
npm install
npm run dev
